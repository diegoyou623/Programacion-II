import java.util.ArrayList;
import java.util.Scanner;

public class empresa {

    static ArrayList<Empleado> empleados = new ArrayList<>();
    static Scanner lea = new Scanner(System.in);

    public static void main(String[] args) {

        int opcion;

        do {

            System.out.println("1- Agregar Empleado");
            System.out.println("2- Pagar Empleado");
            System.out.println("3- Lista de Empleados");
            System.out.println("4- Sub Menu");
            System.out.println("5- Salir");
            System.out.print("Escoja una opcion: ");
            opcion = lea.nextInt();

            switch (opcion) {

                case 1:
                    contratacion();
                    break;

                case 2:
                    pay();
                    break;

                case 3:
                    list();
                    break;

                case 4:
                    submenu();
                    break;

            }

        } while (opcion != 5);

    }

    private static Empleado search(int cod) {

        for (int i = 0; i < empleados.size(); i++) {

            if (empleados.get(i).getCodigo() == cod) {
                return empleados.get(i);
            }

        }

        return null;
    }

    private static void contratacion() {

        System.out.println("1- Empleado Comun");
        System.out.println("2- Empleado por Horas");
        System.out.println("3- Empleado por Ventas");
        System.out.println("4- Empleado Temporal");
        System.out.print("Escoja el tipo: ");
        int tipo = lea.nextInt();

        System.out.print("Ingrese el codigo: ");
        int codigo = lea.nextInt();

        if (search(codigo) == null) {

            System.out.print("Ingrese el nombre: ");
            String nombre = lea.next();

            System.out.print("Ingrese el salario: ");
            double salario = lea.nextDouble();

            switch (tipo) {

                case 1:
                    empleados.add(new empleadoComun(codigo, nombre, salario));
                    break;

                case 2:
                    empleados.add(new empleadoHora(codigo, nombre, salario));
                    break;

                case 3:
                    empleados.add(new empleadoVenta(codigo, nombre, salario));
                    break;

                case 4:
                    empleados.add(new empleadoTemporal(codigo, nombre, salario));
                    break;

                default:
                    System.out.println("Tipo incorrecto.");
            }

        } else {
            System.out.println("El codigo ya existe.");
        }

    }

    private static void pay() {

        System.out.print("Ingrese el codigo: ");
        int codigo = lea.nextInt();

        Empleado emp = search(codigo);

        if (emp != null) {
            System.out.println("Pago: " + emp.pago());
        } else {
            System.out.println("Empleado no encontrado.");
        }

    }

    private static void list() {

        for (int i = 0; i < empleados.size(); i++) {
            System.out.println(empleados.get(i));
        }

    }

    private static void submenu() {

        int opcion;

        do {

            System.out.println("1- Fecha Fin Contrato");
            System.out.println("2- Ingresar Venta");
            System.out.println("3- Ingresar Horas");
            System.out.println("4- Regresar");
            System.out.print("Opcion: ");
            opcion = lea.nextInt();

            switch (opcion) {

                case 1:
                    setFin();
                    break;

                case 2:
                    ventas();
                    break;

                case 3:
                    horas();
                    break;

            }

        } while (opcion != 4);

    }

    private static void setFin() {

        System.out.print("Codigo: ");
        int codigo = lea.nextInt();

        Empleado emp = search(codigo);

        if (emp instanceof empleadoTemporal) {

            System.out.print("Fecha Fin: ");
            String fecha = lea.next();

            ((empleadoTemporal) emp).setFechaFinalizacion(fecha);

        } else {

            System.out.println("No es un empleado temporal.");

        }

    }

    private static void ventas() {

        System.out.print("Codigo: ");
        int codigo = lea.nextInt();

        Empleado emp = search(codigo);

        if (emp instanceof empleadoVenta) {

            System.out.print("Venta: ");
            double venta = lea.nextDouble();

            ((empleadoVenta) emp).agregarVenta(venta);

        } else {

            System.out.println("No es un empleado por ventas.");

        }

    }

    private static void horas() {

        System.out.print("Codigo: ");
        int codigo = lea.nextInt();

        Empleado emp = search(codigo);

        if (emp instanceof empleadoHora) {

            System.out.print("Horas: ");
            int h = lea.nextInt();

            ((empleadoHora) emp).agregarHoras(h);

        } else {

            System.out.println("No es un empleado por horas.");

        }

    }

}