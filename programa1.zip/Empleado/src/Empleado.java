
public class Empleado {
    protected int codigo;
    protected String nombre;
    protected double Salario;

    public Empleado() {
    }

    public Empleado(int codigo, String nombre, double Salario) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.Salario = Salario;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public double getSalario() {
        return Salario;
    }
    
    public double pago(){
        return Salario;
    }
    
    @Override
    public String toString() {
        return "codigo: " + codigo + "\nNombre: +" + nombre + "\nSalario: " + Salario;
    }
}
