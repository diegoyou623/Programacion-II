
public class empleadoTemporal extends Empleado {
    private String fechaFinalizacion;

    public empleadoTemporal() {
    }

    public empleadoTemporal(int codigo, String nombre, double Salario) {
        super(codigo, nombre, Salario);
        
        
        fechaFinalizacion = " ";
    }

    public String getFechaFinalizacion() {
        return fechaFinalizacion;
    }

    public void setFechaFinalizacion(String fechaFinalizacion) {
        this.fechaFinalizacion = fechaFinalizacion;
    }
    
    
    
   @Override
   public String toString(){
       return super.toString() + "\nFecha final: " + fechaFinalizacion;
   }
    
}
