
public class empleadoHora extends Empleado {
    private int horas;
    private double pagoHora;
    
    
    public empleadoHora(int codigo, String nombre, double pagoHora){
        
        super(codigo, nombre, 0);
        
        this.pagoHora = pagoHora;
        horas = 0;
    }
    
    public void agregarHoras(int horas){
        this.horas += horas;
        }
    
    @Override
    public double pago(){
        return horas * pagoHora;
    }
    
    @Override
    public String toString(){
        return super.toString() + "\nHoras: " + horas + "\nPago por hora: " + pagoHora; 
    }
    
}
