
public class empleadoVenta extends Empleado {
    
    private double ventas;

    public empleadoVenta() {
    }

    public empleadoVenta(int codigo, String nombre, double Salario) {
        super(codigo, nombre, Salario);
        
        ventas = 0;
    }
    
    public void agregarVenta(double venta){
        ventas += venta;
    }
    
    @Override
    public double pago(){
        return Salario + (ventas * 0.10);
    }
    
    @Override
    public String toString(){
        return super.toString() + "\nVentas: " + ventas;
    }
}
