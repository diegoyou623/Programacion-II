
public class empleadoComun extends Empleado {
    
    public empleadoComun(int codigo, String nombre, double salario) {
            super(codigo, nombre, salario);
    }
}
